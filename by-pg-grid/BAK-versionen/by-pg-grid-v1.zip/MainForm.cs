using Npgsql;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
// using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PgDataGridWinForms
{
    public class MainForm : Form
    {
        private DataGridView grid = new DataGridView();
        private Button loadButton = new Button();
        private Button saveButton = new Button();
        private Button gtmButton  = new Button();
        private TextBox gtmtextBox  = new TextBox();

        private TextBox textBox00 = new TextBox();
        private TextBox textBox01 = new TextBox();
        private TextBox textBox02 = new TextBox();
        private TextBox textBox03 = new TextBox();
        private TextBox textBox04 = new TextBox();
        private TextBox textBox05 = new TextBox();
        private TextBox textBox06 = new TextBox();
        private TextBox textBox07 = new TextBox();
        private TextBox textBox08 = new TextBox();
        private TextBox textBox09 = new TextBox();
        private TextBox textBox10 = new TextBox();

        private TextBox textBoxCursorCol = new TextBox();
        private TextBox textBoxCursorRow = new TextBox();
        private TextBox textBoxEvent     = new TextBox();


        private DataTable table = new DataTable();
   //     private DataGridViewCellStyle style;
        // TODO: connection string anpassen
        private string connString = "Host=192.168.207.160;Port=5432;Username=postgres;Password=Ole1brumm;Database=RK2";

        public MainForm(int test127)  // hier könnte man von Hauptprogramm command line parameter holen, muss nur umstellen auf 2 Strings oder ein Array
        {
            Text = "GTM: Turbo DataGrid ";
            Width = 1400;
            Height = 900;

            grid.Dock = DockStyle.Top;
            grid.Height = 500;

            
            // 3 Buttons, Abstand 90 Pixel
            loadButton.Text = "Laden";
            loadButton.Top = 510;
            loadButton.Left = 10;
            loadButton.Click += LoadData;

            saveButton.Text = "Speichern";
            saveButton.Top = 510;
            saveButton.Left = 100;
            saveButton.Click += SaveData;

            gtmButton.Text = "Button gtm";
            gtmButton.Top = 510;
            gtmButton.Left = 190;
            gtmButton.Click += ButtonGTM;


            textBoxCursorRow.Text = test127.ToString();    // "-";
        textBoxCursorRow.Width = 40;
        textBoxCursorRow.Top = 510;
        textBoxCursorRow.Left = 1000;

        textBoxCursorCol.Text = "-";
        textBoxCursorCol.Width = 40;
        textBoxCursorCol.Top = 540;
        textBoxCursorCol.Left = 1000;


        textBoxEvent.Text = "-";
        textBoxEvent.Width = 200;
        textBoxEvent.Top = 570;
        textBoxEvent.Left = 1000;


            // Anordnung vertikal
            int startx = 400;
            int starty = 510;
            int hoehe = 30;
            
            textBox00.Text = "t00";
            textBox00.Width = 100;
            textBox00.Top = starty + 0 * hoehe;
            textBox00.Left = startx;

            textBox01.Text = "t01";
            textBox01.Width = 100;
            textBox01.Top = starty + 1* hoehe;
            textBox01.Left = startx;

            textBox02.Text = "t02";
            textBox02.Width = 60;
            textBox02.Top = starty + 2*hoehe;
            textBox02.Left = startx;

            textBox03.Text = "t03";
            textBox03.Width = 60;
            textBox03.Top = starty+ 3* hoehe;
            textBox03.Left = startx;

            textBox04.Text = "t04";
            textBox04.Width = 60;
            textBox04.Top = starty+ 4* hoehe;
            textBox04.Left = startx;

            textBox05.Text = "t05";
            textBox05.Width = 60;
            textBox05.Top = starty + 5 * hoehe;
            textBox05.Left = startx;

            textBox06.Text = "text 06 ist lang";
            textBox06.Width = 60;
            textBox06.Top = starty + 6 * hoehe;
            textBox06.Left = startx;

            textBox07.Text = "t07";
            textBox07.Width = 60;
            textBox07.Top = starty + 7 * hoehe;
            textBox07.Left = startx;

            textBox08.Text = "t08";
            textBox08.Width = 60;
            textBox08.Top = starty + 8 * hoehe;
            textBox08.Left = startx;

            textBox09.Text = "t09";
            textBox09.Width = 60;
            textBox09.Top = starty + 9 * hoehe;
            textBox09.Left = startx;

            textBox10.Text = "t10";
            textBox10.Width = 60;
            textBox10.Top = starty + 10 * hoehe;
            textBox10.Left = startx;




            // Form besteht aus Grid und 3 Buttons
            Controls.Add(grid);
            Controls.Add(textBoxCursorCol);
            Controls.Add(textBoxCursorRow);
            Controls.Add(textBoxEvent);

            Controls.Add(textBox00);
            Controls.Add(textBox01);

            Controls.Add(textBox02);
            Controls.Add(textBox03);
            Controls.Add(textBox04);
            Controls.Add(textBox05);
            Controls.Add(textBox06);
            Controls.Add(textBox07);
            Controls.Add(textBox08);
            Controls.Add(textBox09);
            Controls.Add(textBox10);


            Controls.Add(gtmButton);
            Controls.Add(loadButton);
            Controls.Add(saveButton);

            LoadData(this, EventArgs.Empty); // direktes Laden der SQL Tabelle


        }

        private void LoadData(object sender, EventArgs e)
        {
            // wenn man Tabellen GrossKleinschreiben will, ist es möglich, aber umständlich z.B. "SELECT * FROM public.\"Buchungen\" order by gewerk"
            using var conn = new NpgsqlConnection(connString);
            //  alle Datebnsätze: var adapter = new NpgsqlDataAdapter("SELECT * FROM public.buchpos" order by gewerk", conn);
           //   alle mit AN     : var adapter = new NpgsqlDataAdapter("SELECT * FROM public.buchpos where art='AN' order by gewerk", conn);
           //   auf eine View!!!
           var adapter = new NpgsqlDataAdapter("SELECT * FROM public.test2view", conn);
            var builder = new NpgsqlCommandBuilder(adapter);

            table.Clear();
            adapter.Fill(table);
            grid.DataSource = table;

            // gtm
            //grid.Columns[0].Name = "internal name"; // interner Name
                     
            grid.EnableHeadersVisualStyles = false; // Grundvoraussetzung

            grid.Columns[0].ReadOnly = true; // Spalte 0 zu Testzwecken readonly

            grid.GridColor = Color.Black;
            grid.BackgroundColor = Color.Azure;
            grid.RowHeadersVisible = false;

            grid.Columns[0].HeaderText = "Spalte 0";
            grid.Columns[1].HeaderText = "Spalte 1";

            grid.CellClick += dataGridView1_CellClick;
            grid.CellClick += dataGridView1_CellEnter;
            // gleicher Event wie Klick
            grid.CurrentCellChanged += dataGridView1_CurrentCellChanged;
            grid.CellValueChanged += dataGridView1_CellValueChanged;

            var style = grid.ColumnHeadersDefaultCellStyle;
            style.BackColor = Color.Navy;
            style.ForeColor = Color.White;
            style.Font = new Font(grid.Font, FontStyle.Bold);

        }


        

        // neuer Button Spielwiese für UPDATE 
        private void ButtonGTM(object sender, EventArgs e)
        {
            using var conn = new NpgsqlConnection(connString);
            var adapter = new NpgsqlDataAdapter("SELECT * FROM public.buchpos order by gewerk", conn);
            var builder = new NpgsqlCommandBuilder(adapter);

            table.Clear();
            adapter.Fill(table);
            grid.DataSource = table;

            // gtm
            //grid.Columns[0].Name = "interner Name"; // interner Name

            grid.EnableHeadersVisualStyles = false; // Grundvorrausetzung

            grid.GridColor = Color.Black;
            grid.BackgroundColor = Color.Azure;
            grid.RowHeadersVisible = false;

            grid.Columns[0].HeaderText = "Spalte 0";
            grid.Columns[1].HeaderText = "Spalte 1";

            var style = grid.ColumnHeadersDefaultCellStyle;
            style.BackColor = Color.Navy;
            style.ForeColor = Color.White;
            style.Font = new Font(grid.Font, FontStyle.Bold);




        }

        private void InitializeComponent()
        {
            SuspendLayout();
            // 
            // MainForm
            // 
            ClientSize = new Size(576, 448);
            Name = "MainForm";
            ResumeLayout(false);

        }

        private void SaveData(object sender, EventArgs e)
        {
            using var conn = new NpgsqlConnection(connString);
            var adapter = new NpgsqlDataAdapter("SELECT * FROM public.buchpos", conn);
            var builder = new NpgsqlCommandBuilder(adapter);

            adapter.Update(table);
            MessageBox.Show("Änderungen gespeichert");
        }



        private void dataGridView1_CellClick(object sender,
            DataGridViewCellEventArgs e)
        {
            string zellentext = grid.CurrentCell.Value?.ToString();
            textBox01.Text = zellentext;

            textBoxCursorRow.Text = e.RowIndex.ToString();
            textBoxCursorCol.Text = e.ColumnIndex.ToString();
            textBoxEvent.Text = "CellClick";
        }
        private void dataGridView1_CellEnter(object sender,
            DataGridViewCellEventArgs e)
        {
            textBoxEvent.Text = "Cell Enter";
            update_felder();
        }
        private void dataGridView1_CurrentCellChanged(object sender,
           EventArgs e)  //  
        {
            // TODO: manmuss abfangen, wenn auf Spaltenüberschrift geklickt wird!! --> sonst exception und man fliegt raus!!

            if (grid.CurrentCell == null)
                return;

            textBoxCursorRow.Text = grid.CurrentCell.RowIndex.ToString();
            textBoxCursorCol.Text = grid.CurrentCell.ColumnIndex.ToString();

            string zellentext = grid.CurrentCell.Value?.ToString();
            textBox01.Text = zellentext;
            textBoxEvent.Text = "neue Zelle";

            update_felder();
        }

        private void dataGridView1_CellValueChanged(object sender,
           DataGridViewCellEventArgs e)  //  EventArgs <<<----das geht
        {
            string zellentext = grid.CurrentCell.Value?.ToString();
            textBox01.Text = zellentext;
            textBoxEvent.Text = "Cell value changed";
        }

        // aktualisere Textboxen
        private void update_felder() {
            textBox01.Text = "update-felder";

            int row1;
            row1 = grid.CurrentCell.RowIndex;

            textBox00.Text = grid.Rows[row1].Cells[0].Value.ToString();
            textBox01.Text = grid.Rows[row1].Cells[1].Value.ToString();
            textBox02.Text = grid.Rows[row1].Cells[2].Value.ToString();
            textBox03.Text = grid.Rows[row1].Cells[3].Value.ToString();
            textBox04.Text = grid.Rows[row1].Cells[4].Value.ToString();
            textBox05.Text = grid.Rows[row1].Cells[5].Value.ToString();

        }

    }
}
